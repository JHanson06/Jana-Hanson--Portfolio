document.addEventListener("DOMContentLoaded", function () {
    function checkForm(event) {
        if (event) {
            // Prevent default form action. DO NOT REMOVE THIS LINE
            event.preventDefault();
        }

        const name = document.getElementById("name");
        const email = document.getElementById("email");
        const formErrors = document.getElementById("formErrors");

        let errors = [];

        
        formErrors.innerHTML = '';
        name.classList.remove("error");
        email.classList.remove("error");

        
        if (name.value.trim().length < 1) {
            errors.push("Missing name.");
            name.classList.add("error");
        }

        
        const emailRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,5}$/;
        if (!email.value.match(emailRegex)) {
            errors.push("Invalid or missing email address.");
            email.classList.add("error");
        }

        
        if (errors.length > 0) {
            formErrors.classList.remove("hide");
            const ul = document.createElement("ul");
            errors.forEach(error => {
                const li = document.createElement("li");
                li.textContent = error;
                ul.appendChild(li);
            });
            formErrors.appendChild(ul);
        } else {
            formErrors.classList.add("hide");
            console.log('Name:', name.value);
            console.log('Email:', email.value);
            
        }
    }

    document.getElementById("submitButton").addEventListener("click", checkForm);

    
    document.getElementById("name").addEventListener("input", checkForm);
    document.getElementById("email").addEventListener("input", checkForm);
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.getElementById('contactForm');
        form.addEventListener('submit', checkForm);
    });
});

window.addEventListener('scroll', function() {
    const mediaPopup = document.getElementById('media-popup');
    const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrolled = window.scrollY;

    if (scrolled >= scrollableHeight - 10) {
        mediaPopup.style.display = 'block';
    } else {
        mediaPopup.style.display = 'none';
    }
});